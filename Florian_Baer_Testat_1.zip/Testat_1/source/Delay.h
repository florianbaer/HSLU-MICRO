/*
 * Delay.h
 *
 *  Created on: 07.03.2020
 *      Author: hslu
 */
#ifndef DELAY_H_
#define DELAY_H_


void Delay(float timeout);

#endif /* DELAY_H_ */
