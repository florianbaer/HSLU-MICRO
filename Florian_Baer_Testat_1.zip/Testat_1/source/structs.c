/*
 * structs.c
 *
 *  Created on: 15.03.2020
 *      Author: hslu
 */


